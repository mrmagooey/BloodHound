#!/usr/bin/env bash
# enable-opengraph.sh — Enable OpenGraph extension management in BHCE
#
# Finds the BHCE PostgreSQL container and sets the opengraph_extension_management
# feature flag. Works with default BHCE docker-compose deployments.
#
# Usage:
#   ./enable-opengraph.sh            # auto-detect container
#   ./enable-opengraph.sh <name|id>  # specify container explicitly

set -euo pipefail

FLAG_KEY="opengraph_extension_management"
DB_USER="${BH_POSTGRES_USER:-bloodhound}"
DB_NAME="${BH_POSTGRES_DB:-bloodhound}"

find_bhce_postgres() {
    # Strategy 1: docker compose service name (works if run from BHCE dir)
    local cid
    cid=$(docker compose ps -q app-db 2>/dev/null || true)
    if [[ -n "$cid" ]]; then
        echo "$cid"
        return
    fi

    # Strategy 2: find running postgres container with bloodhound database
    local containers
    containers=$(docker ps --filter "ancestor=postgres:16" --format '{{.ID}}' 2>/dev/null || true)
    if [[ -z "$containers" ]]; then
        # Broader search — any postgres image
        containers=$(docker ps --filter "ancestor=postgres" --format '{{.ID}}' 2>/dev/null || true)
    fi
    if [[ -z "$containers" ]]; then
        # Broadest — look for postgres in image name
        containers=$(docker ps --format '{{.ID}} {{.Image}}' 2>/dev/null | grep -i postgres | awk '{print $1}' || true)
    fi

    for c in $containers; do
        if docker exec "$c" psql -U "$DB_USER" -d "$DB_NAME" -c "SELECT 1" >/dev/null 2>&1; then
            echo "$c"
            return
        fi
    done

    return 1
}

# Resolve container
if [[ $# -ge 1 ]]; then
    CONTAINER="$1"
    echo "[*] Using specified container: $CONTAINER"
else
    echo "[*] Searching for BHCE PostgreSQL container..."
    if ! CONTAINER=$(find_bhce_postgres); then
        echo "[!] Could not find BHCE PostgreSQL container."
        echo "    Make sure BHCE is running (docker compose up -d)."
        echo "    Or specify the container: $0 <container-name-or-id>"
        exit 1
    fi
    CNAME=$(docker inspect --format '{{.Name}}' "$CONTAINER" 2>/dev/null | sed 's|^/||')
    echo "[+] Found container: $CNAME ($CONTAINER)"
fi

run_psql() {
    docker exec "$CONTAINER" psql -U "$DB_USER" -d "$DB_NAME" -tAc "$1"
}

# Check current state
echo "[*] Checking current flag state..."
CURRENT=$(run_psql "SELECT enabled FROM feature_flags WHERE key = '$FLAG_KEY';" 2>/dev/null || echo "MISSING")

if [[ "$CURRENT" == "t" ]]; then
    echo "[+] $FLAG_KEY is already enabled. Nothing to do."
    exit 0
elif [[ "$CURRENT" == "MISSING" ]]; then
    echo "[!] feature_flags table or $FLAG_KEY row not found."
    echo "    Is this a BHCE 8.7.0+ database?"
    exit 1
fi

echo "[-] $FLAG_KEY is currently disabled (enabled=$CURRENT)"

# Enable the flag
echo "[*] Enabling $FLAG_KEY..."
run_psql "UPDATE feature_flags SET enabled = true WHERE key = '$FLAG_KEY';"

# Confirm
AFTER=$(run_psql "SELECT enabled FROM feature_flags WHERE key = '$FLAG_KEY';")
if [[ "$AFTER" == "t" ]]; then
    echo "[+] $FLAG_KEY is now enabled."
    echo ""
    echo "    Restart BloodHound for the change to take effect:"
    echo "      docker compose restart bloodhound"
else
    echo "[!] Flag update failed. Current value: $AFTER"
    exit 1
fi
