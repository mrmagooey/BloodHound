# BloodHound OpenGraph Interconnected Range Dataset

This BloodHound dataset was collected from a SpecterOps range environment for the fictional company K-nexus Global. The environment includes Active Directory, Entra ID, Azure resources, two Okta tenants, Jamf Pro, and GitHub Enterprise (EMU).

The dataset demonstrates cross-platform attack paths spanning all of these platforms using the BloodHound OpenGraph framework.

## Prerequisites

- **BloodHound 8.7.0+** (BHCE or BHE)
- **PostgreSQL database backend** (required for OpenGraph indexing)
- **OpenGraph Extension Management** enabled (for schema auto-management)

## BHCE Setup: PostgreSQL Backend

BHCE defaults to Neo4j for graph storage. OpenGraph data requires PostgreSQL for performant indexing and ingestion. Follow the official guide to switch:

**[Change Backend Database](https://bloodhound.specterops.io/get-started/custom-installation#change-backend-database)**

In short:

1. Set `"graph_driver": "pg"` in `bloodhound.config.json`
2. Remove the Neo4j (`graph-db`) service, its volume, and its health check dependency from `docker-compose.yml`
3. The existing PostgreSQL (`app-db`) container handles both relational and graph storage

### Enable OpenGraph Extension Management

The `opengraph_extension_management` flag must be enabled directly in the PostgreSQL database. This allows BloodHound to automatically manage OpenGraph schema extensions when ingesting data from collectors like OktaHound, GitHound, and JamfHound.

#### Option A: Helper Script (Recommended)

Run the included script, which auto-detects the BHCE PostgreSQL container:

```bash
./enable-opengraph.sh
```

Or specify the container explicitly:

```bash
./enable-opengraph.sh <container-name-or-id>
```

Then restart BloodHound: `docker compose restart bloodhound`

#### Option B: Docker Exec

Find the BHCE PostgreSQL container:

```bash
sudo docker ps | grep postgres
```

Use the container ID to check and set the flag:

```bash
# Check current value
sudo docker exec -it <container-id> psql -U bloodhound -d bloodhound \
  -c "SELECT key, enabled FROM feature_flags WHERE key = 'opengraph_extension_management';"

# Enable
sudo docker exec -it <container-id> psql -U bloodhound -d bloodhound \
  -c "UPDATE feature_flags SET enabled = true WHERE key = 'opengraph_extension_management';"
```

Then restart BloodHound: `docker compose restart bloodhound`

#### Option C: Expose PostgreSQL Port

If you prefer to connect with an external client (DBeaver, pgAdmin, `psql`):

1. Expose the PostgreSQL port by uncommenting the ports line in `docker-compose.yml`:
   ```yaml
       - 127.0.0.1:${POSTGRES_PORT:-5432}:5432
   ```

2. Restart the stack: `docker compose down && docker compose up -d`

3. Connect to the database:
   ```
   Host: localhost
   Port: 5432
   Database: bloodhound
   User: bloodhound
   Password: bloodhoundcommunityedition
   ```

4. Enable the feature flag:
   ```sql
   UPDATE feature_flags SET enabled = true WHERE key = 'opengraph_extension_management';
   ```

5. Restart BloodHound: `docker compose restart bloodhound`

## Ingestion Instructions

Ingest data in the order of the numbered folders. The ordering matters because later datasets reference nodes created by earlier ones.

1. **00-schema** -- Upload schema extension files first via the BloodHound API:
   `PUT /api/v2/opengraph/schema` for each JSON file. If `opengraph_extension_management` is enabled, schemas will auto-register during data upload and you can skip this step.

2. **01-shce** -- Upload SharpHound CE JSON files (Active Directory)
3. **02-azhce** -- Upload AzureHound CE JSON (Entra ID / Azure)
4. **03-entrasso** -- Upload EntraSSSOHound JSON (Entra SSO integrations)
5. **04-oktahound** -- Upload OktaHound JSON (Okta identity graphs). These files can be large; zip them before upload for better performance.
6. **05-jamfhound** -- Upload JamfHound JSON (Jamf Pro device management)
7. **06-githound** -- Upload GitHound JSON (GitHub Enterprise)
8. **07-oktahound-hybrid** -- Upload OktaHound hybrid edge files **last**. These contain cross-platform edges that reference nodes from all previous datasets.

Upload each file via the BloodHound file upload API or the UI's upload feature. ZIP individual JSON files before uploading for better performance, especially for the OktaHound data.

### 08-queries (Optional)

The `08-queries/` folder contains saved Cypher queries organized by collector. Import them via `POST /api/v2/saved-queries/import` or manually add them through the BloodHound UI.

## Data Layout

```
k-nexusglobal-bhce-YYYYMMDD/
  00-schema/                        Schema extensions for OpenGraph node types
    bhce-okta-extension.json          Okta node/edge type definitions
    bhce-github-extension.json        GitHub node/edge type definitions
    bhce-jamf-extension.json          Jamf node/edge type definitions
    bh-scim-extension.json            SCIM provisioning edge definitions
    githound-schema.json              GitHound schema (icons, colors)
    jamfhound-schema.json             JamfHound schema (icons, colors)
  01-shce/                          SharpHound CE -- Active Directory
  02-azhce/                         AzureHound CE -- Entra ID / Azure
  03-entrasso/                      EntraSSSOHound -- Entra SSO integrations
  04-oktahound/                     OktaHound -- Okta identity graph (non-hybrid)
  05-jamfhound/                     JamfHound -- Jamf Pro
  06-githound/                      GitHound -- GitHub Enterprise (EMU)
  07-oktahound-hybrid/              OktaHound -- cross-platform hybrid edges
  08-queries/                       Saved Cypher queries
    hybrid/                           Cross-platform hybrid attack path queries
    oktahound/                        Okta-specific queries
    oktahound-privilege-zones/        Okta privilege zone rules
    githound/                         GitHub-specific queries
    jamfhound/                        Jamf-specific queries
  README.md
```

## Resources

- [Introduction to BloodHound](https://bloodhound.specterops.io/get-started/introduction)
- [OpenGraph Overview](https://bloodhound.specterops.io/opengraph/overview)
- [GitHound](https://github.com/SpecterOps/GitHound)
- [JamfHound](https://github.com/SpecterOps/JamfHound)
- [EntraSSSOHound](https://github.com/SpecterOps/EntraSSSOHound)
- OktaHound (Coming Soon)
